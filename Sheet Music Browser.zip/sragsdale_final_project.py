'''
Author: Samuel Ragsdale
Date finished: 10/11/2024
Assignment Module 8 Final
Description: GUI program designed to be able to display PNG files, the idea being this is opened on a screen and
used similarly to how a piece of sheet music would be used.
'''


#Necessary imports for this program to work
import tkinter as tk
from PIL import Image, ImageTk
import PIL
from tkinter import Toplevel, filedialog, scrolledtext, messagebox
import os

'''This variable just sets the CWD to wherever the program was opened from, this is mainly for the
2 images below, as they are included will open from the relative path.'''
scriptDirectory = os.path.dirname(os.path.abspath(__file__))
os.chdir(scriptDirectory)

'''The central function of this program instantiates a new window when the user selects a valid file (PNG only, currenlty)
and opens it maximized. It also displays a small banner at the top printing the file location.'''
def openImage():
    filePath = filedialog.askopenfilename(filetypes=[("PNG Files", "*.png")])

    if filePath:
        
        newWindow = Toplevel(root)
        newWindow.title("New Window")
        newWindow.geometry("1368x720")
        label = tk.Label(newWindow, text = filePath)
        label.pack()
        newWindow.state("zoomed")

        img = Image.open(filePath)
        img = img.resize((770, 1000), PIL.Image.Resampling.LANCZOS)
        tkImage = ImageTk.PhotoImage(img)

        label = tk.Label(newWindow, image = tkImage, bg = "black")
        label.image = tkImage
        label.pack(expand= True, fill = "both")
        
'''this function runs when the Save Text button is clicked, opens a dialog on where to save & what to name it,
text files only and then pops up an alert when the file saves successfully'''
def saveText():
    
    filePath = filedialog.asksaveasfilename(defaultextension = ".txt",
                                            filetypes=[("Text files", "*.txt"),
                                                       ("All files", "*.*")])
    with open(filePath, "w") as file:
          textContent = textBox.get("1.0", tk.END)
          file.write(textContent)
    return messagebox.showinfo("Save Successful!", f"File successfully saved at: {filePath}")

'''this function runs when the Clear Text button is clicked, asks if the user wants to delete the text,
then deletes it if they select yes, otherwise it does nothing.'''
def clearText():
    response = messagebox.askyesno("Confirmation", "Are you sure you want to delete the text in the text box?")
    if response:
        textBox.delete("1.0", tk.END)
        messagebox.showinfo("Text Deleted", "Text Deleted")
    else:
        pass


'''The root window image is declared here, its size is locked in to keep formatting in check'''
root = tk.Tk()
root.title("Deluxe Image Viewer")
root.geometry("800x600")
root.config(bg = "#2a3b4c")
root.resizable(False, False)


'''two image files provide a little style to the piece'''
image = Image.open("note1.png")
newSize = (55, 50)
resizedImage = image.resize(newSize, PIL.Image.Resampling.LANCZOS) 
photo = ImageTk.PhotoImage(resizedImage)
imageLabel = tk.Label(root, image = photo, bd = 0)
imageLabel.place(relx = 0.20, rely = .15, anchor = "w")

imageTwo = Image.open("note2.png")
newSize = (55, 50)
resizedImageTwo = imageTwo.resize(newSize, PIL.Image.Resampling.LANCZOS) 
photoTwo = ImageTk.PhotoImage(resizedImageTwo)

imageLabel = tk.Label(root, image = photoTwo, bd = 0)
imageLabel.place(relx = 0.80, rely = .15, anchor = "e")



'''This button opens a dialog to select a .PNG file type only and will then run the openImage function
to open the selected image in a new window. Multiple new windows can be opened in this way.'''
openFileLabel = tk.Label(root, text = "Click 'Open File' to open the piece in a new window:",
                         bg = "#2a3b4c", font = "Arial", fg = "white")
openFileLabel.pack(pady = 30)
openWindow = tk.Button(root, text="Open File", command = openImage)
openWindow.pack()


'''The text box provides a place to enter notes or things you want to remember about the piece'''
textBoxLabel = tk.Label(root, text = "Use the provided space to enter notes:",
                        bg = "#2a3b4c", font = "Arial", fg = "white")        
textBoxLabel.pack(padx = 20, pady = (20,0))

textBox = tk.Text(root, height = 20, width = 100)
textBox.insert("1.0", "This piece is in the key of...\n")
textBox.pack(pady = (10,0), padx = 25)


'''this button & assosicated elements provide a way to save entered notes on the piece being worked on.'''
saveTextLabel = tk.Label(root, text = "Click 'Save Text' to save the contents of the text box:",
                         bg = "#2a3b4c", font = "Arial", fg = "white")
saveTextLabel.place(relx = 0, rely = 0.85, anchor = "w")
saveText = tk.Button(root, text = "Save Text", command = saveText) #opens a dialog to save the text as a .txt file
saveText.place(relx = 0.20, rely = 0.90, anchor = "w")

'''The clearTextLabel & associated placement & text all serve to provide a way to quickly clear the
text box, in case the user opens a new piece they can (save) then clear the box to enter new notes.'''
clearTextLabel = tk.Label(root, text = "Click 'Clear Text to erase all text in the text box: ",
                          bg = "#2a3b4c", font = "Arial", fg = "white")
clearTextLabel.place(relx = 1.0, rely = 0.85, anchor = "e")
clearText = tk.Button(root, text = "Clear Text", command = clearText) #opens a confirmation box and if True, clears the text box
clearText.place(relx = 0.90, rely = 0.90, anchor = "e")

root.mainloop()
